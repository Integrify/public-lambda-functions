/**
 * Created by rich on 1/30/17.
 */


function getStep(val) {
    console.log(val)
    return Promise.resolve(val)

}
var outstring = null;
getStep("step1")
    .then(r1 => {
        console.log(r1)
            outstring = r1
    }
    )
    .then(getStep(outstring + '-step2'))
    .then(r2 => console.log(r2))